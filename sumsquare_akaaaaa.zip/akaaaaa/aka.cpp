#include "aka.h"

int sumIt(int n){
    int s = 0;
    int i = 1;
    while (i <= n){
        s = s + (i*i);
        i++;
    }
    return s;
}

int sumRec(int n){
    if(n == 1){
        return 1;
    }else{
        return sumRec(n-1) + (n*n);
    }
}

