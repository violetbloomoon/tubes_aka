#include "aka.h"
#include <iostream>
#include <chrono>

using namespace std;

using std::chrono::high_resolution_clock;
using std::chrono::duration_cast;
using std::chrono::duration;
using std::chrono::milliseconds;

int main()
{
     // rekursif
    /*int n = 100000;
    cout << "inputan: " << n << endl;
    cout << "hasil = " << sumRec(n) << endl;*/

    //iteratif
    /*int n = 1000000;
    cout << "inputan: " << n << endl;
    cout << "hasil = " << sumIt(n) << endl;*/

    int n = 15000;

    auto t1 = high_resolution_clock::now();
    sumIt(n);
    auto t2 = high_resolution_clock::now();

    duration<double, std::micro> ms_double = t2 - t1;
    cout << ms_double.count() << " microseconds" <<endl;

    return 0;
}
