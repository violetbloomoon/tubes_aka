#ifndef AKA_H_INCLUDED
#define AKA_H_INCLUDED

#include <iostream>
using namespace std;

int sumIt(int n);
int sumRec(int n);

#endif // AKA_H_INCLUDED
